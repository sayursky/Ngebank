package com.sayursky.ngebank

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class QuizQuestion(
    val id: String,
    val subject: String,
    val prompt: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String = ""
)

private val sampleQuestions = listOf(
    QuizQuestion("math-1", "Matematika", "Berapakah hasil 8 × 7?", listOf("54", "56", "64", "48"), 1, "8 dikali 7 sama dengan 56."),
    QuizQuestion("math-2", "Matematika", "Berapakah hasil 144 ÷ 12?", listOf("10", "11", "12", "14"), 2, "144 dibagi 12 sama dengan 12."),
    QuizQuestion("indo-1", "Bahasa Indonesia", "Apa sinonim kata 'cermat'?", listOf("Teliti", "Lalai", "Lambat", "Ragu"), 0, "Cermat berarti teliti atau saksama."),
    QuizQuestion("sci-1", "IPA", "Planet yang dikenal sebagai Planet Merah adalah ...", listOf("Venus", "Jupiter", "Mars", "Saturnus"), 2, "Mars tampak kemerahan karena permukaannya kaya oksida besi.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NgebankTheme { QuizApp() } }
    }
}

@Composable
fun NgebankTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = Color(0xFF3659D9),
        secondary = Color(0xFF19A68C),
        background = Color(0xFFF5F7FC),
        surface = Color.White
    )
    MaterialTheme(colorScheme = colors, content = content)
}

private enum class Screen { HOME, QUIZ, RESULT }

@Composable
fun QuizApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedSubject by remember { mutableStateOf("Semua") }
    var questions by remember { mutableStateOf(sampleQuestions) }
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var answered by remember { mutableStateOf(false) }
    var selectedAnswer by remember { mutableIntStateOf(-1) }
    var totalPlayed by remember { mutableIntStateOf(0) }
    var bestScore by remember { mutableIntStateOf(0) }

    fun startQuiz(subject: String) {
        selectedSubject = subject
        questions = sampleQuestions.filter { subject == "Semua" || it.subject == subject }.shuffled()
        index = 0
        score = 0
        answered = false
        selectedAnswer = -1
        screen = Screen.QUIZ
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when (screen) {
            Screen.HOME -> HomeScreen(
                totalPlayed = totalPlayed,
                bestScore = bestScore,
                onStart = { startQuiz(it) }
            )
            Screen.QUIZ -> {
                if (questions.isEmpty()) {
                    Text("Belum ada soal untuk kategori ini.")
                } else {
                    QuizScreen(
                        question = questions[index],
                        number = index + 1,
                        total = questions.size,
                        selectedAnswer = selectedAnswer,
                        answered = answered,
                        score = score,
                        onAnswer = { answer ->
                            if (!answered) {
                                selectedAnswer = answer
                                answered = true
                                if (answer == questions[index].correctIndex) score += 10
                            }
                        },
                        onNext = {
                            if (index < questions.lastIndex) {
                                index++
                                selectedAnswer = -1
                                answered = false
                            } else {
                                totalPlayed++
                                bestScore = maxOf(bestScore, score)
                                screen = Screen.RESULT
                            }
                        }
                    )
                }
            }
            Screen.RESULT -> ResultScreen(
                score = score,
                total = questions.size,
                onHome = { screen = Screen.HOME },
                onRetry = { startQuiz(selectedSubject) }
            )
        }
    }
}

@Composable
private fun HomeScreen(totalPlayed: Int, bestScore: Int, onStart: (String) -> Unit) {
    val subjects = listOf("Semua", "Matematika", "Bahasa Indonesia", "IPA")
    Column(
        modifier = Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Spacer(Modifier.height(18.dp))
        Text("NGEBANK", fontSize = 14.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text("Asah pengetahuanmu.", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 36.sp)
        Text("Pilih kategori dan mulai tantangan kuis.", color = Color(0xFF667085))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Kuis dimainkan", totalPlayed.toString(), Modifier.weight(1f))
            StatCard("Skor terbaik", bestScore.toString(), Modifier.weight(1f))
        }
        Text("Pilih kategori", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        subjects.forEach { subject ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onStart(subject) },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(subject, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(if (subject == "Semua") "Campuran semua kategori" else "Latihan $subject", color = Color.Gray, fontSize = 12.sp)
                    }
                    Text("Mulai  →", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Text("Versi starter • Data contoh tersimpan di kode aplikasi", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text(label, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun QuizScreen(
    question: QuizQuestion,
    number: Int,
    total: Int,
    selectedAnswer: Int,
    answered: Boolean,
    score: Int,
    onAnswer: (Int) -> Unit,
    onNext: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("NGEBANK", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("$number / $total", fontWeight = FontWeight.SemiBold)
        }
        LinearProgressIndicator(progress = { number.toFloat() / total }, modifier = Modifier.fillMaxWidth())
        Text(question.subject.uppercase(), color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(question.prompt, fontSize = 25.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
        question.options.forEachIndexed { i, option ->
            val isCorrect = answered && i == question.correctIndex
            val isWrongSelected = answered && i == selectedAnswer && i != question.correctIndex
            val bg = when {
                isCorrect -> Color(0xFFDDF7EA)
                isWrongSelected -> Color(0xFFFFE5E5)
                else -> Color.White
            }
            Card(
                modifier = Modifier.fillMaxWidth().clickable(enabled = !answered) { onAnswer(i) },
                colors = CardDefaults.cardColors(containerColor = bg),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${'A' + i}.", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(12.dp))
                    Text(option, modifier = Modifier.weight(1f))
                    if (isCorrect) Text("✓", color = Color(0xFF16834D), fontWeight = FontWeight.Bold)
                    if (isWrongSelected) Text("✕", color = Color.Red, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (answered) {
            Text(
                if (selectedAnswer == question.correctIndex) "Benar! +10 poin" else "Belum tepat. Jawaban benar: ${question.options[question.correctIndex]}",
                fontWeight = FontWeight.Bold,
                color = if (selectedAnswer == question.correctIndex) Color(0xFF16834D) else Color(0xFFB54708)
            )
            if (question.explanation.isNotBlank()) Text(question.explanation, color = Color.Gray, fontSize = 13.sp)
        }
        Spacer(Modifier.weight(1f))
        Text("Skor: $score", color = Color.Gray)
        Button(onClick = onNext, enabled = answered, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Text(if (number == total) "Lihat hasil" else "Soal berikutnya")
        }
    }
}

@Composable
private fun ResultScreen(score: Int, total: Int, onHome: () -> Unit, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("SELESAI!", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text("Kerja bagus!", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(18.dp))
        Text(score.toString(), fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
        Text("poin dari maksimal ${total * 10}", color = Color.Gray)
        Spacer(Modifier.height(30.dp))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text("Main lagi") }
        OutlinedButton(onClick = onHome, modifier = Modifier.fillMaxWidth()) { Text("Kembali ke beranda") }
    }
}
