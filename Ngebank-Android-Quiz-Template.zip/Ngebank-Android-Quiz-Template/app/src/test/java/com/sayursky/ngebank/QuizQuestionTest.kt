package com.sayursky.ngebank

import org.junit.Assert.assertEquals
import org.junit.Test

class QuizQuestionTest {
    @Test fun correctAnswerIndexIsWithinOptions() {
        val question = QuizQuestion("test", "Test", "Question?", listOf("A", "B"), 1)
        assertEquals(true, question.correctIndex in question.options.indices)
    }
}
