# Ngebank Android Quiz — Starter Template

Template awal aplikasi kuis Android **native** menggunakan Kotlin dan Jetpack Compose.

## Yang sudah tersedia
- Proyek Android Studio native (bukan website).
- Lobby dengan pilihan kategori.
- Kuis pilihan ganda.
- Urutan soal diacak setiap mulai.
- Feedback benar/salah.
- Skor 10 poin untuk jawaban benar.
- Progress bar dan layar hasil.
- Pemisahan soal berdasarkan kategori.
- Satu unit test dasar untuk model soal.

## Yang belum tersedia
Template ini adalah fondasi awal, bukan aplikasi produksi final. Login, Firebase/Firestore, sinkronisasi antarperangkat, leaderboard online, panel admin terlindungi, timer, riwayat persisten, ikon final, dan pipeline APK perlu dikembangkan dan dikonfigurasi setelah proyek diperiksa. Skor dan statistik saat ini hanya berada dalam memori selama aplikasi berjalan. Soal yang ada merupakan data contoh untuk menguji alur aplikasi, bukan konten bank soal final.

## Cara membuka
1. Unduh dan ekstrak ZIP.
2. Buka Android Studio.
3. Pilih **Open**, lalu pilih folder `Ngebank-Android-Quiz-Template`.
4. Gunakan JDK 17.
5. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh dependensi.
6. Jalankan aplikasi pada emulator atau HP Android dengan USB debugging.

## Cara menambahkan soal
Edit `app/src/main/java/com/sayursky/ngebank/MainActivity.kt`, lalu tambahkan item `QuizQuestion` ke `sampleQuestions`.

Contoh:
```kotlin
QuizQuestion(
    id = "sejarah-1",
    subject = "Sejarah",
    prompt = "Siapa proklamator Indonesia?",
    options = listOf("Soekarno dan Hatta", "Diponegoro", "Kartini", "Sudirman"),
    correctIndex = 0,
    explanation = "Proklamasi dibacakan oleh Soekarno didampingi Mohammad Hatta."
)
```

`correctIndex` dimulai dari 0: pilihan pertama = 0, pilihan kedua = 1, dan seterusnya.

## Identitas aplikasi
- Nama tampilan: Ngebank Quiz
- Application ID: `com.sayursky.ngebank`
- Minimum Android: API 24 (Android 7.0)
- Compile/Target SDK: 35
- Kotlin/JVM: 17

## Build APK
Di Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
Output debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

Belum ada Gradle Wrapper JAR di ZIP ini. Android Studio dapat mengimpor proyek dan menyiapkan Gradle; untuk build command-line, pasang Gradle yang kompatibel atau buat wrapper dari Android Studio/Gradle lokal.

## Keamanan dan privasi
Jangan commit `local.properties`, file service account, token, password, atau kredensial. `google-services.json` dikecualikan dari Git oleh `.gitignore`. Repository GitHub yang diberikan saat pemeriksaan berstatus **Public**; ubah menjadi **Private** di GitHub Settings > General > Danger Zone > Change repository visibility sebelum mengunggah kode privat.
