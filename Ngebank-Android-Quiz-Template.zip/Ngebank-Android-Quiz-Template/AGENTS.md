# Agent Notes
- Keep the app native Android: Kotlin + Jetpack Compose.
- Do not claim Firebase, online sync, or remote leaderboard is configured unless credentials, rules, and integration are verified.
- Do not commit secrets or `google-services.json`.
- Keep question selection filtered by subject.
- Run unit tests and an Android build before reporting success.
- Repository visibility must be Private if source privacy is required.
